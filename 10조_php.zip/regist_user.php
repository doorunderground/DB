<?php
$con=mysqli_connect("localhost","root","5531","db2");
$userID=$_POST["userID"];
$userPW=$_POST["password"];
$userPWCH=$_POST["passwordch"];
$username=$_POST["username"];
$phone=$_POST["phone"];
$usertype=$_POST["user"];

if($userPW==$userPWCH){
    $sql="insert into 고객 (고객ID,비밀번호,이름,휴대폰번호,고객유형) values ('".$userID."','".$userPW."','".$username."','".$phone."','".$usertype."')";
$ret=mysqli_query($con,$sql);
echo "<h1>회원가입에 성공하였습니다. 감사합니다!</h1>";
}
else{
    echo "<h1>비밀번호가 일치하지 않습니다!</h1>";
}

mysqli_close($con);

?>
<IDOCTYPE html>
<HEAD>
<META http-eqoipv="contsnt-type" content=text/html; charset="utf-8">
</HEAD>
<html>
    <body>
    <?php
        echo "<br> <a href='login.php'><--로그인 화면</a>";
        ?>
</body>
       
</html>
