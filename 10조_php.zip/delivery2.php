<!DOCTYPE html>
<html>
<body>

<h1>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;배달현황</h1> 
<hr align="left" style="border: solid 5px black; width: 50%">

<h3>
<tr>
<table border="0">
<?php   
      $con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
      $sql = "SELECT count(*) as '건수' from 주문 where 배달 = '대기중'";
      $ret = mysqli_query($con, $sql);
      $row = mysqli_fetch_array($ret); 
   ?>
    <th><a href = "waiting.php">     &emsp;&emsp;&emsp;&emsp;배달 대기:<?php echo $row['건수']; ?> 건&emsp;&emsp;&emsp;&emsp;</a></th>
    <?php   
   //$con = mysqli_connect("localhost", "root", "jh85926953", "bdbd2") or die("MySQL 접속 실패");
   $sql = "SELECT count(*) as '건수' from 주문 where 배달 = '배달진행'";
   $ret = mysqli_query($con, $sql);
   $row = mysqli_fetch_array($ret);
   ?>
    <th><a href = "proceeding.php">&emsp;&emsp;&emsp;&emsp;배달 진행: <?php echo $row['건수']; ?> 건&emsp;&emsp;&emsp;&emsp; </a></th> 
    <?php   
   //$con = mysqli_connect("localhost", "root", "jh85926953", "bdbd2") or die("MySQL 접속 실패");
   $sql = "SELECT count(*) as '건수' from 주문 where 배달 = '배달완료'";
   $ret = mysqli_query($con, $sql);
   $row = mysqli_fetch_array($ret);
   ?>
    <th><a href = "completion.php">&emsp;&emsp;&emsp;&emsp;배달 완료: <?php echo $row['건수']; ?> 건&emsp;&emsp;&emsp;&emsp; </a></th>
	
</table>
</tr>
</h3>
<br><br>
<?php 
 $ID=$_GET["ID"];
 $userID=$_GET["userID"];
 //$con = mysqli_connect("localhost", "root", "jh85926953", "bdbd2") or die("MySQL 접속 실패");
 $sql = "SELECT 주문.주문ID, 주문.배달, 음식점.음식점이름, 주문.배달주소 
 from 주문,음식점 
 where 주문.주문상태 = '픽업대기중' and 음식점.음식점ID = 주문.음식점ID and 주문.배달업체ID=(select 업체ID from 배달원 where 배달원.배달원ID='".$userID."')";
 $sql2 = "UPDATE 주문 set 배달 = '배달완료' where 배달 = '배달진행' and 주문ID = $ID ";
// $sql3 = "UPDATE 주문 set 배달 = '배달진행' where 배달 = '대기중' and 주문ID = $ID ";
$ret2 = mysqli_query($con, $sql2); 
$ret = mysqli_query($con, $sql);
 echo "<TABLE border = 2>";
 echo "<TR>";
 echo "<th>&emsp;&emsp;음식점이름&emsp;&emsp; </th><th>&emsp;배달주소&emsp;</th><th>&emsp;배달상태&emsp;</th><th>&emsp;배달하기&emsp;</th> ";
 echo "</TR>";


 while($row = mysqli_fetch_array($ret)) 
 {
    echo "<TR>";
    echo "<td>", $row['음식점이름'], "</td>";
    echo "<td>", $row['배달주소'], "</td>";
    echo "<td>" , $row['배달'],"</td>";
    if ($row['배달']=="배달완료")
    {
    echo "<td>", "배달완료 </td>";
    }
    elseif ($row['배달']=="배달진행")
    {
    echo "<td>", "<a href='delivery2.php?ID=",$row['주문ID'],"&userID=",$userID,"'> <--배달완료</a> </td>";
    }
    else
    {
        echo "<td>", "<a href='delivery1.php?ID=",$row['주문ID'],"&userID=",$userID,"'> <--배달진행</a> </td>";
        //$ret3 = mysqli_query($con, $sql3);
        echo "</TR>"; 
    } 
 }

 
 $row = mysqli_fetch_array($ret); 
 echo  "<br>";
 mysqli_close($con);

 echo "</TABLE>"; 

?>
</html>
</body>