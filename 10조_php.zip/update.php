<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
    </head>
    <body>
    <form method="post" action="update_user1.php">
아이디:<input type="text" name="userID"/>
패스워드: <input type="password" name="password"/><br>
이름:<input type="name" name="username"/><br>
휴대폰번호:<input type="text" name="phone"/><br>
</p> <hr>
     <input type="submit" value="수정하기"/>
</form> 


    </body>
</html>