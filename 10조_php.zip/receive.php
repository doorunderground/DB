<?php
	$num1 = 100;
	$num2 = 200;
	$sum = $num1 + $num2;
?>

<html>

<head>
<META http-equiv ="content-type" content = "text/html; charset = utf-8">
</head>

<body>
<h1> 계산 결과 <?php echo $sum ?> 입니다. </h1>

<body>
</html>
 