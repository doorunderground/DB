<br>
<h2>[배달주소] : 
<?php   
    $con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
    
    #$ID=$_GET["ID"];
    #$userID=$_GET["userID"];

    $sql2 = "SELECT 배달주소 FROM 주문 where 주문ID ='2' ";
    $ret = mysqli_query($con, $sql2);

          
     while($row = mysqli_fetch_array($ret)) 
        {
            echo "<TR>";
            echo "<td>", $row['배달주소'], "</td>";
            echo "</TR>";
        }    
   ?> 
</h2>


<br>
<h2>[요청사항] :
    <?php   
    $con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
    
    #$ID=$_GET["ID"];
    #$userID=$_GET["userID"];

    $sql2 = "SELECT 요청사항 FROM 주문 where 주문ID ='2' ";
    $ret = mysqli_query($con, $sql2);

          
     while($row = mysqli_fetch_array($ret)) 
        {
            echo "<TR>";
            echo "<td>", $row['요청사항'], "</td>";
            echo "</TR>";
        }    
   ?> 
</h2>


<br>
<h2>[옵션] :
<?php   
    
    #$ID=$_GET["ID"];
    #$userID=$_GET["userID"];

$sql="SELECT 장바구니.*,메뉴.메뉴이름 from 장바구니,메뉴 where 장바구니.주문ID = '2' and 장바구니.메뉴ID=메뉴.메뉴ID";
$ret=mysqli_query($con,$sql);


$sql2="SELECT 장바구니.장바구니ID,메뉴.메뉴이름,메뉴옵션.옵션,메뉴옵션.내용,장바구니.개수,장바구니.총합가격
from 장바구니,메뉴,메뉴옵션
where 장바구니.주문ID = '2' and 장바구니.옵션번호=메뉴옵션.옵션번호 and 장바구니.메뉴ID=메뉴.메뉴ID";
$ret2=mysqli_query($con,$sql2);

echo "<TABLE border=1>";
echo "<TR>";
echo "<TH>메뉴이름</TH><TH>옵션</TH><TH>내용</TH><TH>개수";
echo"</TR>";



while($row=mysqli_fetch_array($ret))
{
    if($row['옵션번호'])
    {

        $row2=mysqli_fetch_array($ret2);
        echo "<TR>";
        echo "<TD>",$row2['메뉴이름'],"</TD>";
        echo "<TD>",$row2['옵션'],"</TD>";
        echo "<TD>",$row2['내용'],"</TD>";
        echo "<TD>"," ","</TD>";
    }
    else
    {
        echo "<TR>";
        echo "<TD>",$row['메뉴이름'],"</TD>";
        echo "<TD>"," ","</TD>";
        echo "<TD>"," ","</TD>";
        echo "<TD>",$row['개수'],"</TD>";
    }
}

echo "</TABLE>";
?> 

<br>
<h2>[총합가격]:
<?php   
    $con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
    
    #$ID=$_GET["ID"];
    #$userID=$_GET["userID"];

    $sql2 = "SELECT 총합가격 FROM 주문 where 주문ID ='2' ";
    $ret = mysqli_query($con, $sql2);

          
     while($row = mysqli_fetch_array($ret)) 
        {
            echo "<TR>";
            echo "<td>", $row['총합가격'],"원", "</td>";
            echo "</TR>";
        }    
   ?> 
</h2>

