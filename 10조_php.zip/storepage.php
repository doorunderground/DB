<?php
$con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
$userID = $_GET["userID"];


    $sql = "select * from 음식점 where 음식점ID='$userID'";
    $ret = mysqli_query($con,$sql);
     
        echo "<h1> My정보 </h1>";
        echo "<TABLE border =1>" ;
        echo "<TR>";
        echo "<TH>음식점이름</TH><TH>음식점로고</TH><TH>전화번호</TH><TH>주소</TH>";
        echo "</TR>"; 
        while($row = mysqli_fetch_array($ret))
        {
        echo "<TR>";
        //echo "<TD>", $row['이름'],"</TD>";
        echo "<TD>", $row['음식점이름'],"</TD>";
        echo "<TD>", $row['음식점로고'],"</TD>";
        echo "<TD>", $row['전화번호'],"</TD>";
        echo "<TD>", $row['주소'],"</TD>";
        echo "<TR>";  
        }
        mysqli_close($con);
        echo "</TABLE>"; 
    
?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
    </head>
    <body>

        <form method="post" action="store_manage.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'>
        <input type="submit" value="가게 관리"/>
</form>
        <form method="post" action="review_manage.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'> 
        <input type="submit" value="리뷰 관리"/>
</form>
<form method="post" action="store_order.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'> 
        <input type="submit" value="주문 확인"/>
</form>

</form>
        <form method="post" action="login.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'> 
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; <input type="submit" value="로그아웃하기"/>
    </form>

    </body>
</html>