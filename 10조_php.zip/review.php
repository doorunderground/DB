<!DOCTYPE html>
<html>
<body>

<h3> 소림마라[영남대점] </h3>
<h2> 평점 : 
   <?php   
   $con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
   $ID=$_GET["ID"];
   $userID=$_GET["userID"];
   $sql2 = "SELECT avg(별점) as '평점' FROM 리뷰 where 음식점ID = '$ID' GROUP BY (음식점ID) ";
   $ret = mysqli_query($con, $sql2);

          
    while($row = mysqli_fetch_array($ret)) 
      {
            echo "<TR>";
            echo "<td>", $row['평점'], "</td>";
            echo "</TR>";
      }    
   ?> 
</h2>
<hr align="left" style="border: solid 5px black; width: 48%">

<?php

   $con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
   
   $sql  = "SELECT 고객ID, 내용, 별점, 사장님말씀 FROM 리뷰 where 음식점ID= '$ID' ";
   $sql2 = "select avg(별점) From 리뷰 group by 음식점ID = '$ID' ";
   
   $ret = mysqli_query($con, $sql);

   if($ret) {
      $count = mysqli_num_rows($ret);
   }
   else {
      echo "userTBl 조회 실패". "<br>";
      echo "실패 원인 :".mysqli_error($con);
      exit();
   }

   echo "<TABLE border =1>";
   echo "<TR>";
   echo "<th>&emsp;&emsp;고객ID&emsp;&emsp; </th><th>&emsp;내용&emsp;</th><th>&emsp;별점&emsp;</th><th>&emsp;사장님말씀&emsp;</th>";
   echo "</TR>";

   while($row = mysqli_fetch_array($ret)) 
   {
      echo "<TR>";
      echo "<td>", $row['고객ID'], "</td>";
      echo "<td>", $row['내용'], "</td>";
      echo "<td>", $row['별점'], "</td>";
      echo "<td>", $row['사장님말씀'], "</td>";
      echo "</TR>"; 
   }
   echo  "<br>";

   mysqli_close($con);

   echo "</TABLE>"; 
   echo "<br> <a href='Ras.php?ID=",$ID,"&userID=",$userID," '> <--음식점 페이지로</a> ";


?>





</body>
</html>