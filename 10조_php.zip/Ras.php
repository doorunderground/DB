<?php
   $con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
   
   $sql  = "SELECT * FROM 음식점";
   
   $ret = mysqli_query($con, $sql);

   if($ret) {
      $count = mysqli_num_rows($ret);
   }
   else {
      echo "userTBl 조회 실패". "<br>";
      echo "실패 원인 :".mysqli_error($con);
      exit();
   }
   $ID=$_GET["ID"];
   $userID=$_GET["userID"];
?>

<!DOCTYPE html>
<html>
<body>

&emsp;&emsp;<img src="logo.png" alt="food_logo" width="15%" height="125px" > 

<h1>&emsp;&emsp;&emsp;&nbsp;&nbsp;음식점</h1>
<p>&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp; 소림마라(영남대점)</p> 

<div class="star-ratings">    
<div
    class="star-ratings-fill space-x-2 text-lg"
    :style="{ width: ratingToPercent + '%' }"
   >
   <span style="color:red">영업중</span> &emsp;&emsp;&emsp;&emsp;&nbsp;<span>★</span><span>★</span><span>★</span><span>★</span>
</div>
 
<hr align="left" style="border: solid 5px black; width: 23%">

<?php

$con=mysqli_connect("localhost","root","5531","db2");
$sql="select * from 음식점 where 음식점ID='".$ID."'";
$ret=mysqli_query($con,$sql);
while($row = mysqli_fetch_array($ret))
    {
        echo "<TR>";
        echo "<TD>", "소개 : ", $row['소개'],"</TD><br>";
        echo "<TD>", "최소배달금액 : ", $row['최소배달금액'],"원","</TD><br>";
        echo "<TD>", "전화번호 : ", $row['전화번호'],"</TD><br>";
        echo "<TD>", "주소 : ", $row['주소'],"</TD><br>";
        $s_time=date('H:i',strtotime($row['영업시작시간']));
        $e_time=date('H:i',strtotime($row['영업종료시간']));
        echo "<TD>", "영업시간 : ", $s_time," ~ ", $e_time,"</TD><br>";
        $time=date('i분',strtotime($row['평균배달시간']));
        echo "<TD>", "평균배달시간 : ", $time," </TD><br>";
        echo "<TR>";  
    }
?>




<h3>
<tr>
 <table border="2">
    <th>&emsp;&emsp;&emsp;&emsp;메뉴&emsp;&emsp;&emsp;&emsp;</th>
    <th><a href="review.php?userID=<?php echo $userID?>&ID=<?php echo $ID?>">&emsp;&emsp;&emsp;&emsp;리뷰&emsp;&emsp;&emsp;&emsp; </a></th>
</table>
</tr>
</h3>


<br>
<h3>

<figure>
<form method="post" action="basket.php">
<input type = "hidden" name="userID" value=<?php echo $userID ?>>
    <input type = "hidden" name="ID" value=<?php echo $ID ?>>
    <input type = "hidden" name="menuID" value='R2-1'>
<input type="image" src="food.png" alt="food_logo" width="10%" height="150px"/>
</form>
JMT 마라탕 <br> 12,000원<br>
</figure>

<figure>
<form method="post" action="basket2.php">
<input type = "hidden" name="userID" value=<?php echo $userID ?>>
    <input type = "hidden" name="ID" value=<?php echo $ID ?>>
    <input type = "hidden" name="menuID" value='R2-2'>
<input type="image" src="food2.png" alt="food_logo" width="10%" height="150px"/>
</form>
JMT 마라샹궈<br> 15,000원~25,000원<br>
</figure>

<figure>
</form>
<form method="post" action="basket3.php">
<input type = "hidden" name="userID" value=<?php echo $userID ?>>
    <input type = "hidden" name="ID" value=<?php echo $ID ?>>
    <input type = "hidden" name="menuID" value='R2-3'>
<input type="image" src="food3.png" alt="food_logo" width="10%" height="150px"/>
<br>JMT 꿔바로우 <br>13,000원<br>
</form>
</figure>
</h3> <br>

<?php echo "<br> <a href='category.php?ID=",$ID,"&userID=",$userID," '> <--카테고리</a> "; ?>

</body>
</html>