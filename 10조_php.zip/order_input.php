<?php
$con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
$userID= $_GET["userID"];
$ID=$_GET["ID"];
$payment=$_GET["payment"];
$request=$_GET["request"];
$price=$_GET["total_price"];
$delivery=$_GET["delivery"];
$sql="select concat(도로명,상세주소) as '배달주소' from 주소 where ID='".$userID."'";
$ret=mysqli_query($con,$sql);
$row=mysqli_fetch_array($ret);
$time=date("Y-m-d H:i:s");

if($delivery=="예")
{
    $i=rand(1,3);

    switch($i)
    {
        case 1 :
            $D_ID="I1";
            break;
            
        case 2 :
            $D_ID="I2";
            break;
        case 3 :
            $D_ID="I3";
            break;
        default:
        echo "오류!";
        break;
    }
    $sql="INSERT INTO `db2`.`주문` (배달업체ID,고객ID, 음식점ID,생성일,수정일,요청사항 ,결제수단, 총합가격,배달주소) 
    VALUES ('".$D_ID."','".$userID."', '".$ID."','".$time."','".$time."','".$request."' ,'".$payment."', '".$price."','".$row["배달주소"]."')";
    $ret=mysqli_query($con,$sql);

    if($ret)
    {
        echo "주문이 완료되었습니다!<br>";
        $sql="update 장바구니 set 주문ID = (select 주문ID from 주문 where 고객ID='".$userID."' and 음식점ID='".$ID."' and 생성일='".$time."' and 수정일='".$time."') where 주문ID is null";
        $ret2=mysqli_query($con,$sql);

        if($ret2)
        {
            $sql="select 주문ID from 주문 where 고객ID='".$userID."' and 음식점ID='".$ID."' and 생성일='".$time."'";
            $ret3=mysqli_query($con,$sql);
            $row = mysqli_fetch_array($ret3);
            $orderID=$row["주문ID"];

            
            $sql="select 장바구니.*,메뉴.메뉴이름
            from 장바구니,메뉴
            where 장바구니.고객ID='".$userID."' and 장바구니.주문ID ='".$orderID."' and 장바구니.메뉴ID=메뉴.메뉴ID";
            $ret3=mysqli_query($con,$sql);



            $sql="select 장바구니.장바구니ID,메뉴.메뉴이름,메뉴옵션.옵션,메뉴옵션.내용,장바구니.개수,장바구니.총합가격
            from 장바구니,메뉴,메뉴옵션
            where 장바구니.고객ID='".$userID."' and 장바구니.주문ID ='".$orderID."' and 장바구니.옵션번호=메뉴옵션.옵션번호 and 장바구니.메뉴ID=메뉴.메뉴ID";
            $ret4=mysqli_query($con,$sql);

            echo "<TABLE border=1>";
            echo "<TR>";
            echo "<TH>메뉴이름</TH><TH>옵션</TH><TH>내용</TH><TH>개수</TH><TH>가격</TH>";
            echo"</TR>";

            while($row=mysqli_fetch_array($ret3))
            {
                if($row['옵션번호'])
                {

                    $row2=mysqli_fetch_array($ret4);
                    echo "<TR>";
                    echo "<TD>",$row2['메뉴이름'],"</TD>";
                    echo "<TD>",$row2['옵션'],"</TD>";
                    echo "<TD>",$row2['내용'],"</TD>";
                    echo "<TD>"," ","</TD>";
                    echo "<TD>",$row2['총합가격'],"</TD>";
                }
                else
                {
                    echo "<TR>";
                    echo "<TD>",$row['메뉴이름'],"</TD>";
                    echo "<TD>"," ","</TD>";
                    echo "<TD>"," ","</TD>";
                    echo "<TD>",$row['개수'],"</TD>";
                    echo "<TD>",$row['총합가격'],"</TD>";
                }

                $num=$row['개수'];

            }

echo "</TABLE>";
echo "총합가격 : ",$price,"원<br>";


        }
        else
        {
            echo "안돼!";
        }

    }
    else
    {
        echo "109주문 실패!";
    }
}
else
{
    $sql="INSERT INTO `db2`.`주문` (고객ID, 음식점ID,생성일,수정일,요청사항 ,결제수단, 총합가격) 
    VALUES ('".$userID."','".$ID."','".$time."','".$time."','".$request."' ,'".$payment."', '".$price."')";
    
$ret=mysqli_query($con,$sql);

if($ret)
    {
        echo "주문이 완료되었습니다!<br>";
        $sql="update 장바구니 set 주문ID = (select 주문ID from 주문 where 고객ID='".$userID."' and 음식점ID='".$ID."' and 생성일='".$time."' and 수정일='".$time."') where 주문ID is null";
        $ret2=mysqli_query($con,$sql);

        if($ret2)
        {
            $sql="select 주문ID from 주문 where 고객ID='".$userID."' and 음식점ID='".$ID."' and 생성일='".$time."'";
            $ret3=mysqli_query($con,$sql);
            $row = mysqli_fetch_array($ret3);
            $orderID=$row["주문ID"];

            
            $sql="select 장바구니.*,메뉴.메뉴이름
            from 장바구니,메뉴
            where 장바구니.고객ID='".$userID."' and 장바구니.주문ID ='".$orderID."' and 장바구니.메뉴ID=메뉴.메뉴ID";
            $ret3=mysqli_query($con,$sql);



            $sql="select 장바구니.장바구니ID,메뉴.메뉴이름,메뉴옵션.옵션,메뉴옵션.내용,장바구니.개수,장바구니.총합가격
            from 장바구니,메뉴,메뉴옵션
            where 장바구니.고객ID='".$userID."' and 장바구니.주문ID ='".$orderID."' and 장바구니.옵션번호=메뉴옵션.옵션번호 and 장바구니.메뉴ID=메뉴.메뉴ID";
            $ret4=mysqli_query($con,$sql);

            echo "<TABLE border=1>";
            echo "<TR>";
            echo "<TH>메뉴이름</TH><TH>옵션</TH><TH>내용</TH><TH>개수</TH><TH>가격</TH>";
            echo"</TR>";

            while($row=mysqli_fetch_array($ret3))
            {
                if($row['옵션번호'])
                {

                    $row2=mysqli_fetch_array($ret4);
                    echo "<TR>";
                    echo "<TD>",$row2['메뉴이름'],"</TD>";
                    echo "<TD>",$row2['옵션'],"</TD>";
                    echo "<TD>",$row2['내용'],"</TD>";
                    echo "<TD>"," ","</TD>";
                    echo "<TD>",$row2['총합가격'],"</TD>";
                }
                else
                {
                    echo "<TR>";
                    echo "<TD>",$row['메뉴이름'],"</TD>";
                    echo "<TD>"," ","</TD>";
                    echo "<TD>"," ","</TD>";
                    echo "<TD>",$row['개수'],"</TD>";
                    echo "<TD>",$row['총합가격'],"</TD>";
                }

                $num=$row['개수'];

            }

echo "</TABLE>";
echo "총합가격 : ",$price,"원<br>";


        }
        else
        {
            echo "안돼!";
        }

    }
    else
    {
        echo "189주문 실패!";
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
    </head>
    <body>

        <form method="post" action="myinformation.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'>
        <input type = "hidden" name="types" value='1'>
        <input type="submit" value="메인으로 돌아가기"/>
    </form>

    </body>
</html>