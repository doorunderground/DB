<?php
$con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
   
$userID=$_GET["userID"];
$menuID=$_GET["menuID"];
$ID=$_GET["ID"];
$num=$_GET["num"];

$sql="select 가격 from 메뉴 where 메뉴ID='".$menuID."'";
    $ret1=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($ret1);
    $menu=$row['가격'];

for($i=0;$i<count($_GET["add"]);$i=$i+1)
{
    $ADD=$_GET["add"][$i];

    $sql="select 가격 from 메뉴옵션 where 옵션번호='".$ADD."'";
    $ret1=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($ret1);
    $option=$row['가격'];

    $sql="insert into 장바구니 (고객ID,메뉴ID,음식점ID,옵션번호,개수,총합가격) 
    values('".$userID."','".$menuID."','".$ID."','".$ADD."','".$num."','".$option."')";
    $ret2=mysqli_query($con,$sql);
    if($ret2)
    {
    $sql="select 메뉴.메뉴이름, 메뉴옵션.옵션,메뉴옵션.내용 from 메뉴,메뉴옵션 
    where 메뉴.메뉴ID='".$menuID."' and 메뉴옵션.옵션번호='".$ADD."'";
        $ret3=mysqli_query($con,$sql);
        $row=mysqli_fetch_array($ret3);
        echo "| ",$row['옵션']," " ,$row['내용']," ";
    }
    else
    {
        echo "담기 실패! <br>";
    }


}
echo "| 장바구니에 담겼습니다!","<br>";
$sql="insert into 장바구니 (고객ID,메뉴ID,음식점ID,옵션번호,개수,총합가격) values('".$userID."','".$menuID."','".$ID."',null,'".$num."','".$menu."')";
$ret2=mysqli_query($con,$sql);



?>

<IDOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<form method="get" action="Ras.php">
<input type = "hidden" name="userID" value='<?php echo $userID ?>'>
<input type = "hidden" name="ID" value='<?php echo $ID ?>'>
<input type="submit" value="음식점으로"/>
    </form>

<form method="get" action="basket_list.php">
<input type = "hidden" name="userID" value='<?php echo $userID ?>'>
<input type = "hidden" name="ID" value='<?php echo $ID ?>'>
<input type="submit" value="장바구니로"/>
    </form>
</body>
</html>