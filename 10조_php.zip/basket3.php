<?php
$userID= $_POST["userID"];
$menuID= $_POST["menuID"];
$ID= $_POST["ID"];
?>


<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
    </head>
    <body>

    <form method="get" action="basket_input.php">
        <img src="food3.PNG" alt="good_logo"width="10%" height="150px"><br>
       <h2>JMT 꿔바로우</h2>
        <h3>추가</h3>
        사이즈 大 <input type="checkbox" name="add[]" value="61"/>

        <br>주문 개수 : <input type="text" name="num" value="1"/><br>
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'>
    <input type = "hidden" name="menuID" value='<?php echo $menuID ?>'>
    <input type = "hidden" name="ID" value='<?php echo $ID ?>'>
        <input type="submit" value="담기"/>
    </form>
       
    <form method="get" action="Ras.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'>
    <input type = "hidden" name="ID" value='<?php echo $ID ?>'>
        <input type="submit" value="음식점으로"/>
    </form>

    </body>
</html>