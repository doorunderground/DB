<?php
$con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
   
$userID=$_GET["userID"];

$sql="select 장바구니.*,메뉴.메뉴이름
from 장바구니,메뉴
where 장바구니.고객ID='".$userID."' and 장바구니.주문ID is null and 장바구니.메뉴ID=메뉴.메뉴ID";
$ret=mysqli_query($con,$sql);


$sql2="select 장바구니.장바구니ID,메뉴.메뉴이름,메뉴옵션.옵션,메뉴옵션.내용,장바구니.개수,장바구니.총합가격
from 장바구니,메뉴,메뉴옵션
where 장바구니.고객ID='".$userID."' and 장바구니.주문ID is null and 장바구니.옵션번호=메뉴옵션.옵션번호 and 장바구니.메뉴ID=메뉴.메뉴ID";
$ret2=mysqli_query($con,$sql2);
$price=0;
$total_price=0;
echo "<h1> 장바구니 </h1>";
echo "<TABLE border=1>";
echo "<TR>";
echo "<TH>메뉴이름</TH><TH>옵션</TH><TH>내용</TH><TH>개수</TH><TH>가격</TH><TH>취소</TH>";
echo"</TR>";



while($row=mysqli_fetch_array($ret))
{
    if($row['옵션번호'])
    {

        $row2=mysqli_fetch_array($ret2);
        echo "<TR>";
        echo "<TD>",$row2['메뉴이름'],"</TD>";
        echo "<TD>",$row2['옵션'],"</TD>";
        echo "<TD>",$row2['내용'],"</TD>";
        echo "<TD>"," ","</TD>";
        echo "<TD>",$row2['총합가격'],"</TD>";
        echo "<TD>"," ","</TD>";
        $price+=$row2['총합가격'];
        //echo"<TD>","<a href='basket_delete.php'장바구니ID=",$row['장바구니ID'],">삭제</a></TD>";
    }
    else
    {
        echo "<TR>";
        echo "<TD>",$row['메뉴이름'],"</TD>";
        echo "<TD>"," ","</TD>";
        echo "<TD>"," ","</TD>";
        echo "<TD>",$row['개수'],"</TD>";
        echo "<TD>",$row['총합가격'],"</TD>";
        $price+=$row['총합가격'];
        $price=$price*$row['개수'];
        $total_price+=$price;
        $price=0;
        echo"<TD>","<a href='basket_delete.php'장바구니ID=",$row['장바구니ID'],">삭제</a></TD>";
    }
}

mysqli_close($con);
echo "</TABLE>";

echo "<TD> 총합가격 : </TD>", $total_price,"원 <br>";
$userID=$_GET["userID"];
$ID=$_GET["ID"];
?>

<IDOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<form method="get" action="Ras.php">
<input type = "hidden" name="userID" value='<?php echo $userID ?>'>
<input type = "hidden" name="ID" value='<?php echo $ID ?>'>
<input type="submit" value="음식점으로"/>
    </form>
    <form method="get" action="order_by_user.php">
<input type = "hidden" name="userID" value='<?php echo $userID ?>'>
<input type = "hidden" name="ID" value='<?php echo $ID ?>'>
<input type="submit" value="주문하기"/>
    </form>
</body>
</html>
