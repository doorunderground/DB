<?php
 $con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
$userID = $_REQUEST["userID"];
//$types=$_POST["types"];
//$pwd = $_POST["pwd"];

$sql = "SELECT * from 고객 where 고객ID ='$userID'";
$ret = mysqli_query($con,$sql);

if($ret){
    
    echo "<h1> My정보 </h1>";
echo "<TABLE border =1>" ;
echo "<TR>";
echo "<TH>고객이름</TH><TH>고객ID</TH><TH>휴대폰번호</TH><TH>등급</TH><TH>생성일</TH><TH>수정일</TH><TH>계정상태</TH><TH>고객유형</TH>";
echo "</TR>"; 
while($row = mysqli_fetch_array($ret))
{
echo "<TR>";
echo "<TD>", $row['이름'],"</TD>";
echo "<TD>", $row['고객ID'],"</TD>";
echo "<TD>", $row['휴대폰번호'],"</TD>";
echo "<TD>", $row['등급'],"</TD>";
echo "<TD>", $row['생성일'],"</TD>";
echo "<TD>", $row['수정일'],"</TD>";
echo "<TD>", $row['계정상태'],"</TD>";
echo "<TD>", $row['고객유형'],"</TD>";
echo "<TR>";  
}
mysqli_close($con);
echo "</TABLE>"; 
}
else
{
    echo "<h2>로그인 정보가 틀렸습니다. !!";

}

?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
    </head>
    <body>

        <form method="post" action="category.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'>
        <input type="submit" value="주문시작하기"/>
    </form>

    </form>
        <form method="post" action="my_order_list.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'> 
        <input type="submit" value="주문확인하기"/>
    </form>

    </form>
        <form method="post" action="update.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'> 
        <input type="submit" value="회원정보 수정하기"/>
    </form>

    </form>
        <form method="post" action="login.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'> 
        &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; <input type="submit" value="로그아웃하기"/>
    </form>


    </body>
</html>