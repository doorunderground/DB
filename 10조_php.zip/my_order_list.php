<?php

$con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
$userID=$_POST["userID"];


$sql="SELECT 주문.주문ID,음식점.음식점이름,주문.배달주소,주문.총합가격
from 주문,음식점 where 주문.음식점ID=음식점.음식점ID and 주문.고객ID='".$userID."'";
$ret=mysqli_query($con,$sql);

echo "<h1> 주문내역 </h1>";
  echo "<TABLE border =1>" ;
  echo "<TR>";
  echo "<TH>주문ID</TH><TH>음식점이름</TH><TH>배달주소</TH><TH>총합가격</TH><TH>상세내용</TH>";
  echo "</TR>"; 
  while($row = mysqli_fetch_array($ret))
 {
   echo "<TR>";
   echo "<TD>", $row['주문ID'],"</TD>";
   echo "<TD>", $row['음식점이름'],"</TD>";
   echo "<TD>", $row['배달주소'],"</TD>";
   echo "<TD>", $row['총합가격'],"</TD>";
   echo"<TD>","<a href='order_basket.php?orderID=",$row['주문ID'],"&userID=",$userID,"'>상세내용</a></TD>";
   echo "<TR>";  
  }
mysqli_close($con);
 echo "</TABLE>"; 
?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
    </head>
    <body>

        <form method="post" action="myinformation.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'>
        <input type = "hidden" name="types" value='1'>
        <input type="submit" value="메인으로 돌아가기"/>
    </form>

    </body>
</html>
