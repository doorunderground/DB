<?php
$con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
$userID = $_POST["userID"];
//$types=$_REQUEST["types"];
$pwd = $_POST["pwd"];

$sql = "select * from 고객 where 고객ID='$userID'";
$ret = mysqli_query($con,$sql);
$row=mysqli_fetch_array($ret);

if(empty($row))
{
    echo "<script>alert('로그인 정보가 없습니다.')</script>";
    echo "<script>location.replace('login.php');</script>";
    
}
if($row['비밀번호']!==$pwd)
{
    echo "<script>alert('비밀번호가 맞지 않습니다.')</script>";
    echo "<script>location.replace('login.php');</script>";
}
else
{   
    $usertype=$row["고객유형"];
    if($usertype==="사장님"){
        
        Header("Location:storepage.php?userID=$userID");   
        mysqli_close($con);
    }
    else if($usertype==="고객"){
        Header("Location:myinformation.php?userID=$userID&types=0");
        mysqli_close($con);
    }
    else{
        Header("Location:delivery.php?userID=$userID&types=0");
        mysqli_close($con);
    }
}
?>
