<IDOCTYPE html>
<head>
<META http-eqoipv="contsnt-type" content=text/html; charset="utf-8">
</HEAD>
<html>

<form method="post" action="regist_user.php">
아이디 : &emsp;&emsp;&emsp;&nbsp;<input type="text" name="userID"/> <br>
패스워드 : &emsp;&emsp;&nbsp;<input type="password" name="password"/><br>
패스워드 확인 : <input type="password" name="passwordch"/><br><br>
이름 :&emsp;&nbsp;&nbsp;&nbsp;&emsp;&nbsp;<input type="name" name="username"/><br>
휴대폰번호 :&nbsp;<input type="text" name="phone"/><br>
고객유형 : &emsp;<select name="user"  size="1">
            <option>고객</option> <option>사장님</option>
            <option>배달원</option>
         </select>
</p> <hr>
     <input type="submit" value="등록하기"/>
</form> 

</html>