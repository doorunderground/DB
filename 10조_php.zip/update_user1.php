<?php
$con=mysqli_connect("localhost","root","5531","db2");
$userPW=$_POST["password"];
$username=$_POST["username"];
$phone=$_POST["phone"];

$sql="update `고객` set 비밀번호 = '".$userPW."', 이름 = '".$username."', 휴대폰번호 = '".$phone."' WHERE 고객ID = '".$userID."'";
$ret=mysqli_query($con,$sql);

if($ret=1){ 
    echo "<h1>회원정보 수정에 성공하였습니다. 감사합니다!</h1>";
}
else{
    echo "정보수정에 실패하였습니다.";
}

mysqli_close($con);

?>
<IDOCTYPE html>
<HEAD>
<META http-eqoipv="contsnt-type" content=text/html; charset="utf-8">
</HEAD>
<html>
    <body>
    <?php
        echo "<br> <a href='login.php'><--로그인 화면</a>";
        ?>
</body>
       
</html>
