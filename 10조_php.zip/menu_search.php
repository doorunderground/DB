<?php
   $con=mysqli_connect("localhost","root","5531","db2") or die("MySQL 접속 실패 !!");
   $userID= $_POST["userID"];
   $메뉴이름 = $_POST["메뉴이름"];

   $sql  = "SELECT * from 음식점 
   where 음식점ID = any(select 음식점ID from 메뉴 where 메뉴이름 LIKE '%".$메뉴이름."%')";

     
$ret = mysqli_query($con,$sql);

echo "<h1> 음식점 조회 결과 </h1>";
echo "<TABLE border =1>" ;
echo "<TR>";
echo "<TH>음식점이름</TH><TH>음식점로고</TH><TH>둘러보기</TH>";
echo "</TR>"; 
while($row = mysqli_fetch_array($ret))
{
 echo "<TR>";
 echo "<TD>", $row['음식점이름'],"</TD>";
 echo "<TD>", $row['음식점로고'],"</TD>";
 echo"<TD>","<a href='Ras.php?ID=",$row['음식점ID'],"&userID=",$userID,"'>둘러보기</a></TD>";
 echo "<TR>";  
}
mysqli_close($con);
echo "</TABLE>"; 
echo "<br> <a href='category.php?userID=",$userID,"'> <--카테고리선택창으로</a> ";

?>