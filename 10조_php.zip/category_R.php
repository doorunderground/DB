<?php
   $con=mysqli_connect("localhost","root","5531","db2") or die("MySQL 접속 실패 !!");
   $카테고리 = $_POST["카테고리"];
   $userID=$_POST["userID"];

  $sql = "SELECT 음식점.*,avg(리뷰.별점) AS '평점' FROM 음식점, 리뷰 
  WHERE 리뷰.음식점ID=음식점.음식점ID AND 음식점.음식점ID=any(SELECT 음식점ID FROM 분류 WHERE 카테고리='".$카테고리."') 
  group by (음식점.음식점ID)";
   
   
$ret = mysqli_query($con,$sql);

  echo "<h1> 음식점 조회 결과 </h1>";
  echo "<TABLE border =1>" ;
  echo "<TR>";
  echo "<TH>음식점이름</TH><TH>음식점로고</TH><TH>평점</TH><TH>둘러보기</TH>";
  echo "</TR>"; 
  while($row = mysqli_fetch_array($ret))
 {
   echo "<TR>";
   echo "<TD>", $row['음식점이름'],"</TD>";
   echo "<TD>", $row['음식점로고'],"</TD>";
   echo "<TD>", $row['평점'],"</TD>";
   echo"<TD>","<a href='Ras.php?ID=",$row['음식점ID'],"&userID=",$userID,"'>둘러보기</a></TD>";
   echo "<TR>";  
  }
mysqli_close($con);
 echo "</TABLE>"; 
?>

<!DOCTYPE html>
<html>
<body>

<form method="post" action="category.php">
        <input type = "hidden" name="userID" value='<?php echo $userID ?>'>
        <input type="submit" value="카테고리 선택창으로"/>
    </form>

</body>
</html>