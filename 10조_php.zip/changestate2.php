<!DOCTYPE html>
<html>
<body>

<h1>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;주문확인</h1>
<hr align="left" style="border: solid 5px black; width: 50%">

<?php
	$con = mysqli_connect("localhost", "root", "5531", "db2") or die("MySQL 접속 실패");
	$storeID=$_GET['userID'];
	$주문ID = $_GET["ID"];
	$sql  = "SELECT 주문ID, 생성일, 수정일, 결제수단, 주문상태, 배달, 총합가격 FROM 주문 where 주문.음식점ID='".$storeID."'";

    $sql2 = "UPDATE 주문 set 주문상태 = '픽업대기중' where 주문상태 = '조리중' and 주문ID = '".$주문ID."'";
    $sql3 = "UPDATE 주문 set 주문상태 = '조리중' where 주문상태 = '접수대기중' and 주문ID = '".$주문ID."' ";
	$ret2 = mysqli_query($con, $sql2);
	$ret = mysqli_query($con, $sql);

	if($ret) {
		$count = mysqli_num_rows($ret);
	}
	else {
		echo "userTBl 조회 실패". "<br>";
		echo "실패 원인 :".mysqli_error($con);
		exit();
	}

	echo "<TABLE border =1>";
	echo "<TR>";
	echo "<th>&emsp;&emsp;주문번호&emsp;&emsp; </th><th>&emsp;주문시각&emsp;</th><th>&emsp;수정일&emsp;</th>";
	echo "<th>&emsp;결제수단&emsp;</th><th>&emsp;주문상태&emsp;</th><th>&emsp;배달&emsp;</th><th>&emsp;총합가격&emsp;</th><th>&emsp;선택하기&emsp;</th>";
	echo "</TR>";

	while($row = mysqli_fetch_array($ret)) {
		echo "<TR>";
		echo "<th th onClick = location.href='order2.php'>", $row['주문ID'], "</th>";
		echo "<td>", $row['생성일'], "</td>";
		echo "<td>", $row['수정일'], "</td>";
		echo "<td>", $row['결제수단'], "</td>";
		echo "<td>", $row['주문상태'], "</td>";
		echo "<td>", $row['배달'], "</td>";
		echo "<td>", $row['총합가격'], "</td>", "<br>";
       
        if($row['주문상태']=="픽업대기중")
        {
			echo "<td>", "픽업대기중</td>";
        }
		else if($row['주문상태']=="픽업완료")
        {
            echo "<TD>픽업완료</TD>";
        }
        else if ($row['주문상태']=="조리중")
        {
            echo "<td>", "<a href='changestate2.php?ID=",$row['주문ID'],"&userID=",$storeID,"'> <--조리완료.</a> </td>";
        }
        else
        {
            echo "<td>", "<a href='changestate.php?ID=",$row['주문ID'],"&userID=",$storeID,"'> <--접수하기</a> </td>"; 
            //$ret3 = mysqli_query($con, $sql3);
        }
		echo "</TR>"; 
	}

?>
</body>
</html>

