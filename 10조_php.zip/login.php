<IDOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<center> 
<h1>Login</h1>
<form method="post" action="mid.php">
         아이디 : &nbsp;&nbsp; <input type="text" name ="userID"> <br>
         비밀번호 : <input type="password" name="pwd"> <br>
           <input type="hidden" name="types" values='0'/>
           <input type="submit" value="로그인"/> <br>
           <input type="submit" value="아이디/비밀번호찾기"/> <br>
   </form> 
   
   <form method="post" action="regist.php">
   <input type="submit" value="가입하기"/><br>
</form>
</center> 

</body>
</html>
